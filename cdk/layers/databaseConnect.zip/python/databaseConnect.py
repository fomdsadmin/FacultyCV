import boto3
import json

sm_client = boto3.client('secretsmanager')

def getCredentials():
    credentials = {}

    response = sm_client.get_secret_value(SecretId='facultyCV/credentials/databaseCredentialsCluster')
    secrets = json.loads(response['SecretString'])
    credentials['username'] = secrets['username']
    credentials['password'] = secrets['password']
    credentials['host'] = secrets['host']
    credentials['db'] = 'postgres'
    return credentials

def get_connection(psycopg2, host):
    credentials = getCredentials()
    
    conn = psycopg2.connect(
        host=host,
        database=credentials['db'],
        user=credentials['username'],
        password=credentials['password']
    )

    return conn